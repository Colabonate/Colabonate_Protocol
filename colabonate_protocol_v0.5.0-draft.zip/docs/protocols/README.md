# Colabonate – Protocol Documentation

This directory contains the complete protocol specification for Colabonate. Documents describe the *what* and *why* of the protocol as an open standard for the freedom of interaction on Bitcoin — completely separated from any specific implementation.

---

## Reading Paths

### For Implementers (building a compatible client)

| Step | Document | Why |
|------|----------|-----|
| 1 | [core/vision.md](core/vision.md) | Understand what the protocol is and isn't |
| 1a | [core/openness-model.md](core/openness-model.md) | What you MUST implement (Protocol Layer) vs. what's reference-server-only (Coordination Layer) |
| 2 | [core/protocol-spec-v1.md](core/protocol-spec-v1.md) | Technical overview and API |
| 3 | [core/roles.md](core/roles.md) | Participant roles and permissions |
| 4 | [core/nostr-events.md](core/nostr-events.md) | All event schemas (Kinds 30017–30029, 30402–30423, 31922–31925) |
| 5 | [core/ticket-system.md](core/ticket-system.md) | Central interaction object |
| 6 | [core/escrow-protocol.md](core/escrow-protocol.md) | Non-custodial payment & escrow paths |
| 7 | [core/escrow-canister-protocol.md](core/escrow-canister-protocol.md) | ICP native-Bitcoin escrow (Path 2) |
| 8 | [GLOSSARY.md](GLOSSARY.md) | Canonical terms |

### For Buyers and Sellers (understanding trade workflows)

| Document | Description |
|----------|-------------|
| [workflows/buy-protocol.md](workflows/buy-protocol.md) | How to buy: discovery → payment → completion |
| [workflows/sell-protocol.md](workflows/sell-protocol.md) | How to sell: offer creation → fulfillment |
| [workflows/cooperation-protocol.md](workflows/cooperation-protocol.md) | Multi-party project collaboration |
| [workflows/booking-protocol.md](workflows/booking-protocol.md) | Bookable resources: time-based offers, NIP-52 calendars |
| [workflows/agent-marketplace-protocol.md](workflows/agent-marketplace-protocol.md) | Optional extension: bookable AI agents (Agent Setup offers) |
| [workflows/dispute-protocol.md](workflows/dispute-protocol.md) | What happens when something goes wrong |

### For Governance and DAO Participants

| Document | Description |
|----------|-------------|
| [governance/dao-codex.md](governance/dao-codex.md) | Foundation DAO constitution |
| [governance/dao-creation-protocol.md](governance/dao-creation-protocol.md) | Creating a community DAO |
| [governance/economic-protocol.md](governance/economic-protocol.md) | COLA token and fee structure |
| [governance/governance-roadmap.md](governance/governance-roadmap.md) | Phase-by-phase governance plan |

### For Identity and Reputation

| Document | Description |
|----------|-------------|
| [identity/identity-protocol.md](identity/identity-protocol.md) | 4-level identity system (Level 0–3) |
| [core/reputation-protocol.md](core/reputation-protocol.md) | COL-Points and review system |

### For Legal and Compliance Research

| Document | Description |
|----------|-------------|
| [core/legal-binding-layer.md](core/legal-binding-layer.md) | Opt-in DAO+Codex transaction binding |
| [governance/dao-creation-protocol.md](governance/dao-creation-protocol.md) | Community DAO with custom Codex |

---

## Complete Document Index

### core/

| Document | Status | Description |
|----------|--------|-------------|
| [vision.md](core/vision.md) | Draft | Protocol philosophy and scope |
| [protocol-spec-v1.md](core/protocol-spec-v1.md) | Draft | Technical spec v1 |
| [roles.md](core/roles.md) | Draft | Participant roles |
| [ticket-system.md](core/ticket-system.md) | Draft | Ticket types and state machine |
| [nostr-events.md](core/nostr-events.md) | Draft | Nostr event schemas (30017–30029, 30402–30423, 31416–31424, 31922–31925) |
| [escrow-protocol.md](core/escrow-protocol.md) | Draft | Non-custodial payment & escrow (Direct-Pay + ICP) |
| [escrow-canister-protocol.md](core/escrow-canister-protocol.md) | Draft | ICP native-Bitcoin escrow canister (Path 2) |
| [payment-architecture.md](core/payment-architecture.md) | Draft | Bitcoin-native, non-custodial payment rails |
| [openness-model.md](core/openness-model.md) | Draft | Three-layer architecture: Protocol (normative) / Coordination (reference-server) / Client (open) |
| [reputation-protocol.md](core/reputation-protocol.md) | Draft | COL-Points and reviews |
| [legal-binding-layer.md](core/legal-binding-layer.md) | Draft | Opt-in DAO+Codex binding |
| security-model.md | Planned | Threat model |
| protocol-versioning.md | Planned | Versioning for implementers |

### identity/

| Document | Status | Description |
|----------|--------|-------------|
| [identity-protocol.md](identity/identity-protocol.md) | Draft | 4-level identity system |
| proximity-proof.md | Planned | Level 2 peer verification detail |

### workflows/

| Document | Status | Description |
|----------|--------|-------------|
| [buy-protocol.md](workflows/buy-protocol.md) | Phase 1 | Buyer flow |
| [sell-protocol.md](workflows/sell-protocol.md) | Phase 1 | Seller flow |
| [cooperation-protocol.md](workflows/cooperation-protocol.md) | Phase 2 | Multi-party cooperation |
| [booking-protocol.md](workflows/booking-protocol.md) | Draft (implemented in code) | Bookable resources, time-based offers (NIP-52) |
| [agent-marketplace-protocol.md](workflows/agent-marketplace-protocol.md) | Draft (optional extension) | Agent Setup workflow: offer → booking → workspace → HITL → review/dispute |
| [dispute-protocol.md](workflows/dispute-protocol.md) | Phase 4 | Conflict resolution |

### governance/

| Document | Status | Description |
|----------|--------|-------------|
| [dao-codex.md](governance/dao-codex.md) | Roadmap | Foundation DAO constitution |
| [dao-creation-protocol.md](governance/dao-creation-protocol.md) | Phase 4 | User-created DAOs |
| [economic-protocol.md](governance/economic-protocol.md) | Phase 4 | COLA token and fees |
| [governance-roadmap.md](governance/governance-roadmap.md) | Living | Phase-by-phase roadmap |
| [dao-technology-stack.md](governance/dao-technology-stack.md) | Draft | At-a-glance: DAO tech stack, why no general-purpose blockchain |

---

## Status Tags

All documents use consistent status tags:

| Tag | Meaning |
|-----|---------|
| `Phase 1` | Core protocol specification |
| `Phase 2` | Extension protocol specification |
| `Phase 3` | Advanced identity and reputation |
| `Phase 4` | Governance and conflict resolution |
| `Roadmap` | Concept exists, timeline open |
| `Draft` | Active working document |
| `Stable` | Ready for implementation |

---

## Glossary

For all technical terms (Ticket, Escrow, Pubkey, HID, COL-Points, etc.) → [GLOSSARY.md](GLOSSARY.md)

---

## Architecture Decisions

For the reasoning behind key protocol choices → [docs/decisions/INDEX.md](../decisions/INDEX.md)
