# Glossary – Colabonate Protocol

## Important: Bitcoin-only

Colabonate is explicitly **Bitcoin-only**. Terms like "Smart Contract" (in the Ethereum sense),
"NFT", "ERC-721", "Solana", or "Polygon" do not apply to this stack and are not used.
Bitcoin-native equivalents are listed at the bottom of this document.

---

## Core Terms

| Term | Definition |
|------|-----------|
| **Ticket** | Central interaction object — represents a contract between parties. Tracks payment, status, and deliverables. |
| **Offer** | A seller's listing in the marketplace, published as a Nostr Kind 30017 event. |
| **Escrow** | Held-fund payment handling. In Colabonate this is **non-custodial**: Path 2 uses an ICP canister holding native Bitcoin (provably no human control); Path 1 Direct-Pay holds no funds. See [escrow-protocol.md](core/escrow-protocol.md). |
| **Direct-Pay** | Path 1 payment — buyer pays seller directly (Lightning Address, NWC, or Cashu P2PK) with **no escrow** and **no platform custody**. Buyer protection is reputation, not held funds. |
| **ICP Escrow Canister** | Path 2 escrow agent: an Internet Computer canister holding **native Bitcoin** via threshold-ECDSA, with provably no human control (blackholed or DAO-controlled). See [escrow-canister-protocol.md](core/escrow-canister-protocol.md). |
| **escrowProvider** | Ticket field discriminating the payment path: `NONE` (Direct-Pay), `CUSTODIAL_LEGACY` (Hold-Invoice, never public), `ICP` (canister escrow). |
| **Cashu** | Ecash protocol (NIP-60/61) enabling non-custodial payments via third-party mints. Used as a Direct-Pay rail (P2PK). Colabonate never operates its own mint. |
| **NWC** | Nostr Wallet Connect (NIP-47) — connects to the user's own Lightning wallet for non-custodial pay/receive. |
| **LNURL-Auth** | Passwordless authentication via Lightning wallet (LUD-04). No email, no password. |
| **Nostr** | Decentralized protocol for events and messages (no central server). All protocol state changes are published as Nostr events. |
| **Pubkey** | Public key = user identity. One Lightning wallet generates one pubkey per service domain. |
| **k1** | Challenge string for LNURL-Auth (random, single-use nonce). |
| **Sats** | Satoshi — smallest Bitcoin unit (1 BTC = 100,000,000 sats). All payments in Colabonate are denominated in sats. |
| **Soulbound** | Non-transferable credential bound to a pubkey via Nostr event signature. Cannot be bought, sold, or transferred. |
| **Relay** | Nostr server that routes and stores events. Not a central service — the protocol works with any NIP-01 compliant relay. |
| **Hold Invoice** | A BOLT11 Lightning invoice not auto-settled — funds held until the holder settles/cancels. **Legacy** in Colabonate: the custodial Hold-Invoice escrow stack remains behind a kill-flag and is never activated in production (PDC: see ADR-253). |
| **Biotoken** | A cryptographic hash of biometric data generated on-device. The hash is one-way — the original biometric cannot be recovered from it. |
| **Lightspark Grid** | Enterprise Lightning infrastructure with automatic pathfinding/liquidity. **Observe-track** (not implemented); was earlier drafts' performance layer. |
| **Spark Stablecoins** | Lightning-native price-stable assets. **Observe-track** (not implemented). |
| **Unified Wallet** | Historical abstraction name for the multi-wallet connection model. The protocol now connects to the user's own wallets (NWC, Alby, Cashu, WebLN) without hosting a wallet. |
| **Codex Fork** | A Bitcoin-based economic sub-unit governed by a Codex. Conceptually tied to the RSK contract layer — **observe-track** (RSK not implemented). |
| **RBTC** | Native token of the RSK sidechain. 1:1 pegged to Bitcoin via two-way peg. Used for gas on RSK. **Observe-track.** No ETH involved. |
| **NIP-57 Zap** | Nostr Lightning payment event (tipping, micro-rewards). **Observe-track.** |
| **Rating Ticket** | A formal ticket type for structured feedback after a completed transaction. Triggers a Nostr Kind 30024 event and COL-Points award upon mutual submission. |
| **Return Ticket** | A ticket type for product returns and refund processes initiated by the buyer within the seller's defined return window. |

---

## Agent Marketplace Terms (optional extension — PDC: ADR-398)

> The Agent Marketplace is an **optional protocol extension**; none of these terms are required for a "Colabonate-compatible" implementation. Full workflow: [workflows/agent-marketplace-protocol.md](workflows/agent-marketplace-protocol.md).

| Term | Definition |
|------|-----------|
| **Agent Profile** | Identity/capability record of an AI agent, owned by a `User` (optionally company-bound). One user may own several (ADR-304). |
| **Agent Setup** | An `Offer` with `offerType = AGENT_SETUP` (Kind 30017/30402, tag `offer_type=agent_setup`): a bookable AI agent (ADR-305). |
| **Agent Billing Model** | How an Agent Setup is billed: `ONE_TIME` \| `PER_HOUR` \| `PER_TOKEN` \| `SUBSCRIPTION`. Snapshotted onto the ticket at creation (ADR-312). `PER_HOUR`/`SUBSCRIPTION` are not implemented. |
| **Workspace** | Reference execution environment (ICP canister) for one agent booking; holds agent state, runs the agent, meters compute. Not required for protocol compatibility (ADR-311). |
| **Human-in-the-Loop (HITL)** | The owner acts as approval/escalation instance; `qualityGateRequired` gates the buyer's `→ COMPLETED` until the owner approves (ADR-308). |
| **Agent Network** | A standing team of agents, the agent-side counterpart of a human Network cooperation (Kind 31424 reserved, ADR-328). |
| **Agent Review** | Kind **31419** — portable multi-dimension review (`accuracy`, `speed`, `reliability`, `quality`, `would_reuse`) published alongside the generic review on a completed Agent Setup ticket (ADR-307). |
| **Verified Agent Badge** | Kind **31423** — replaceable, platform-signed badge (`status = verified \| unverified`); a Colabonate claim, not a decentralised attestation (ADR-315). |
| **Capability Attestation** | Kind **31417** — ticket-bound customer claim about an agent's capabilities; designed, not yet published (reserved, FU-413). |
| **Agent Trust Score** | Reference-server multi-signal score for an Agent Profile (claims, completion rate, owner reputation, stake, disputes). Descriptive — not a normative formula (ADR-317). |

---

## Identity Terms

| Term | Definition |
|------|-----------|
| **HID** | Human Identity — the Colabonate 4-level identity system (Level 0–3). Level 3 uses Humanode biometric verification. |
| **Identity Level** | One of four trust tiers (0 = anonymous, 1 = Nostr profile, 2 = peer verified, 3 = HID verified). Higher levels unlock more protocol features. |
| **Humanode Biomapper** | External biometric ZK proof system used for Identity Level 3. Proves uniqueness (one person, one HID) without storing biometric data. |
| **Proximity Proof** | A Nostr Kind 30026 event published by a verifier after an in-person encounter with a subject. Two proximity proofs from different verifiers = Identity Level 2. |
| **1P1V** | One Person One Vote — a governance voting model requiring Identity Level 3 (HID verified). Each verified human has exactly one vote, regardless of token holdings. |

---

## Reputation Terms

| Term | Definition |
|------|-----------|
| **COL-Points** | Off-chain, non-transferable reputation accumulation. Earned through protocol participation (completed tickets, reviews, governance). Cannot be purchased. |
| **COLA Token** | Transferable governance token (planned on RSK / Bitcoin sidechain). Used for token-weighted governance voting and staking. Not a currency — all payments remain in sats. Token layer is **observe-track** (RSK not implemented; see [economic-protocol.md](governance/economic-protocol.md)). |
| **Reputation Score** | A float (0.0–5.0) computed from star reviews, completion rate, dispute history, and COL-Points. Publicly visible on Nostr. |
| **Soulbound Event** | A Nostr event that functions as a non-transferable credential (e.g. identity verification, mediator badge). Soulbound via pubkey binding. |

---

## Governance Terms

| Term | Definition |
|------|-----------|
| **Codex** | The constitutional framework of a DAO — defines rules, voting procedures, dispute resolution, and sanction levels. |
| **Codex Fork** | A community DAO that creates its own Codex, optionally based on the Foundation Codex as a template. |
| **DAO** | Decentralized Autonomous Organization. In Colabonate: a community governed by a published Codex and Nostr-based voting. Not an EVM DAO — governance is via Nostr events. |
| **Foundation DAO** | The Colabonate Foundation's own DAO, which governs the protocol specification itself. |
| **Community DAO** | A user-created DAO with a custom Codex. Independent of the Foundation DAO. See [dao-creation-protocol.md](governance/dao-creation-protocol.md). |
| **Liquid Democracy** | Delegation model: token holders can delegate their governance vote to a delegate for 90 days, revocable anytime. |
| **Quorum** | Minimum percentage of eligible voters who must participate for a governance vote to be valid. |
| **Protocol Registry** | A Nostr-based registry of community-published protocol extensions and workflow templates (Phase 5). |
| **Royalty Ticket** | A ticket type that automatically distributes a sat-denominated fee to a protocol author each time their community protocol is used (Phase 5). |

---

## Roles

| Role | Description | Status |
|------|-------------|--------|
| **Initiator** | Creates offers, pays into escrow, initiates cooperation | Phase 1 |
| **Partner** | Accepts ticket, delivers service or goods, receives payment | Phase 1 |
| **Mediator** | Community expert, mediates disputes at Level 2 | Phase 3 |
| **Arbitrator** | DAO juror, decides disputes at Level 3 | Phase 4 |
| **Observer** | Reads public offers, views reputation | Phase 1 |

> Note: In the Phase 1 core flow, roles are represented as `sellerPubkey` (Initiator) and `buyerPubkey` (Partner). Both roles are generalized to `Initiator/Partner` in the broader protocol spec to support cooperation use cases where both parties are equal.

---

## Ticket Status

| Status | Meaning |
|--------|---------|
| `PENDING` | Ticket created, waiting for seller acceptance |
| `ACCEPTED` | Seller accepted — Phase 2 escrow Phase 1 payment requested |
| `IN_PROGRESS` | Buyer paid Phase 1/2 escrow — work underway |
| `COMPLETED` | Delivery confirmed, payment released, review window open |
| `DISPUTED` | Dispute opened — escrow frozen pending resolution |
| `CANCELLED` | Cancelled by buyer, seller, or timeout |

---

## Offer Status

| Status | Meaning |
|--------|---------|
| `ACTIVE` | Visible in marketplace |
| `CLOSED` | Manually closed by seller |
| `ARCHIVED` | Expired or withdrawn |

---

## Bitcoin-native Equivalents for EVM Terms

The following table shows EVM-ecosystem terms and their Colabonate Bitcoin-native equivalents. EVM terms are **not used** in this repository.

| EVM term | Colabonate equivalent | Notes |
|----------|-----------------------|-------|
| Smart Contract | Lightning Escrow | Hold Invoices + Nostr event rules |
| NFT / Soulbound NFT | Nostr Event + pubkey signature | Kind 30021 credential |
| DAO Token Vote | Nostr-based Governance Vote | Kind 30022 event |
| On-chain storage | Nostr Relay | Events, not blockchain storage |
| Gas fees | Lightning routing fees | Paid by payer in sats |
| ERC-20 token | RRC-20 token (RSK) | RSK is Bitcoin-secured, not Ethereum |
| Wallet address | Lightning pubkey (via LNURL-Auth) | secp256k1 keypair |
| Bridge | RSK two-way peg (BTC ↔ RBTC) | No ETH involved |

---

## Deprecated / Not Used

These terms are **explicitly not used** in the Colabonate Protocol. If you see them in documentation, it is an error that should be corrected.

- Ethereum, ETH, EVM
- Solana, SOL
- Polygon, MATIC
- Smart Contract (in EVM sense)
- NFT (in ERC-721 sense)
- Gas, Gas fees (in EVM sense)
- Airdrop (tokens are distributed via participation, not dropped)
- DeFi (Colabonate is not a DeFi protocol)

---

*Part of the Colabonate Protocol Specification | [docs/protocols/](./README.md)*
